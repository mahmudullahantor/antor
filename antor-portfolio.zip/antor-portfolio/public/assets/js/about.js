(function (A) {
'use strict';
const { $, $$, el } = A.dom;


/** Fills the text, photo and links of the page from the saved site settings. */
function applySettings({ settings }) {
  $('#hero-title').textContent = settings.headline;
  $('#hero-lead').textContent = settings.lead;
  $('#about-title').textContent = settings.aboutTitle;
  $('#about-text').replaceChildren(...settings.aboutParagraphs.map((text) => el('p', {}, text)));
  $('#skills').replaceChildren(...settings.skills.map((skill) => el('li', {}, skill)));

  $$('[data-link]').forEach((a) => {
    const href = settings.links[a.dataset.link];
    if (href) a.href = href;
    else a.closest('li')?.remove() ?? a.remove();
  });

  const email = $('#emailBtn');
  if (settings.email) {
    email.href = `mailto:${settings.email}`;
    email.hidden = false;
  }

  const portrait = $('#portrait');
  const fallback = () => portrait.replaceChildren(el('span', { 'aria-hidden': 'true' }, (settings.name || 'A').charAt(0).toUpperCase()));
  if (settings.photo) {
    const img = new Image();
    img.alt = `Portrait of ${settings.name}`;
    img.addEventListener('error', fallback);
    img.src = settings.photo;
    portrait.replaceChildren(img);
  } else {
    fallback();
  }
}

A.about = { applySettings };
})(window.Antor = window.Antor || {});
