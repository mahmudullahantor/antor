(function (A) {
'use strict';

/**
 * Loads site content from the Node backend. If the backend is not available
 * (GitHub Pages, or opening index.html directly) it uses data/content.js / content.json.
 */
async function loadContent() {
  // Opened by double-clicking index.html (file://) or hosted without a backend: use the bundled copy.
  const bundled = () => (window.ANTOR_CONTENT ? { content: window.ANTOR_CONTENT, live: false } : null);
  if (location.protocol === 'file:') {
    const local = bundled();
    if (local) return local;
    throw new Error('data/content.js is missing. Run "npm run export-static".');
  }
  try {
    const res = await fetch('api/content', { headers: { Accept: 'application/json' } });
    if (!res.ok || !(res.headers.get('content-type') || '').includes('json')) throw new Error('no backend');
    return { content: await res.json(), live: true };
  } catch {
    const local = bundled();
    if (local) return local;
    const res = await fetch('data/content.json');
    if (!res.ok) throw new Error('Could not load the site content.');
    return { content: await res.json(), live: false };
  }
}

async function sendContact(payload) {
  const res = await fetch('api/contact', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const error = new Error(data.error || 'Could not send your message.');
    error.errors = data.errors || {};
    throw error;
  }
  return data;
}

A.api = { loadContent, sendContact };
})(window.Antor = window.Antor || {});
