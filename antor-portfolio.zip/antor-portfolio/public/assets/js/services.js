(function (A) {
'use strict';
const { $, el, putImage } = A.dom;


function renderServices({ services, settings }) {
  const tabs = $('#tabs');
  const panel = $('#panel');
  let selected = 0;

  function drawTabs() {
    tabs.replaceChildren(...services.map((service, i) =>
      el('button', {
        class: 'tab', type: 'button', role: 'tab', 'aria-selected': String(i === selected),
        onclick: () => { selected = i; drawTabs(); drawPanel(true); }
      }, service.name)));
  }

  function drawPanel(animate) {
    const service = services[selected];
    if (!service) return;
    const href = service.link && settings.links[service.link];
    const action = href
      ? el('a', { class: 'btn btn-orange', href, target: '_blank', rel: 'noopener' }, service.cta)
      : el('button', { class: 'btn btn-orange', type: 'button', 'data-contact': '', 'data-service': service.name }, service.cta);

    const media = el('div', { class: `media m-${service.category}` });
    putImage(media, service.image, service.name);

    panel.replaceChildren(
      el('div', {},
        el('h3', {}, service.name),
        el('p', {}, service.text),
        service.items.length ? el('h4', {}, 'What you get') : null,
        el('ul', {}, service.items.map((item) => el('li', {}, item))),
        action),
      service.image ? media : null
    );
    if (animate) {
      panel.classList.remove('fade');
      void panel.offsetWidth;
      panel.classList.add('fade');
    }
  }

  drawTabs();
  drawPanel(false);
}

A.services = { renderServices };
})(window.Antor = window.Antor || {});
