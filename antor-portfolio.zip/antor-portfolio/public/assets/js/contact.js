(function (A) {
'use strict';
const { $, $$, el } = A.dom;
const { sendContact } = A.api;


/** Contact dialog. Sends to the backend; without a backend it opens the visitor's email app instead. */
function initContact() {
  const dialog = $('#contact-dialog');
  const form = $('#contact-form');
  const select = $('#contact-service');
  const status = $('#contact-status');
  const submit = $('button[type="submit"]', form);
  let live = true;
  let settings = { email: '', links: {} };

  document.addEventListener('click', (event) => {
    const close = event.target.closest('[data-close]');
    if (close) close.closest('dialog').close();
  });
  dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });

  function setStatus(message, kind = '') {
    status.textContent = message;
    status.className = `form-status ${kind}`.trim();
  }
  function showErrors(errors = {}) {
    $$('[data-err]', form).forEach((node) => {
      const message = errors[node.dataset.err] || '';
      node.textContent = message;
      form.elements[node.dataset.err]?.setAttribute('aria-invalid', String(Boolean(message)));
    });
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    showErrors();
    const data = Object.fromEntries(new FormData(form));

    if (!live) {
      // Static hosting: no server to receive the message.
      if (settings.email) {
        const subject = encodeURIComponent(`Project enquiry: ${data.service}`);
        const body = encodeURIComponent(`${data.message}\n\n${data.name}`);
        window.location.href = `mailto:${settings.email}?subject=${subject}&body=${body}`;
      } else if (settings.links.instagram) {
        window.open(settings.links.instagram, '_blank', 'noopener');
      }
      return;
    }

    submit.disabled = true;
    setStatus('Sending…');
    try {
      await sendContact(data);
      form.reset();
      setStatus('Thank you! Your message was sent. I’ll reply by email soon.', 'ok');
    } catch (error) {
      showErrors(error.errors);
      setStatus(error.message, 'bad');
    } finally {
      submit.disabled = false;
    }
  });

  return {
    setup(content, isLive) {
      live = isLive;
      settings = content.settings;
      select.replaceChildren(
        el('option', { value: 'General question' }, 'General question'),
        ...content.services.map((service) => el('option', { value: service.name }, service.name))
      );
    },
    open(service = '') {
      showErrors();
      setStatus('');
      if (service && [...select.options].some((option) => option.value === service)) select.value = service;
      dialog.showModal();
      form.elements.name.focus();
    }
  };
}

A.contact = { initContact };
})(window.Antor = window.Antor || {});
