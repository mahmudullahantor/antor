(function (A) {
'use strict';
const { $, $$ } = A.dom;


const dialogOpen = () => Boolean(document.querySelector('dialog[open]'));
const titleCase = (text) => text.charAt(0).toUpperCase() + text.slice(1);

/** Horizontal full-screen slider: nav links, arrows, dots, keyboard, wheel, swipe and #hash links. */
function initSlider() {
  const track = $('#track');
  const viewport = $('#viewport');
  const slides = $$('.slide');
  const names = slides.map((slide) => slide.id.replace('s-', ''));
  const prev = $('#prev');
  const next = $('#next');
  const dots = $('#dots');
  let index = 0;
  let locked = false;

  names.forEach((name, i) => {
    const dot = document.createElement('button');
    dot.className = 'dot';
    dot.type = 'button';
    dot.title = titleCase(name);
    dot.setAttribute('aria-label', `Go to ${name}`);
    dot.addEventListener('click', () => go(i));
    dots.append(dot);
  });

  function go(target, instant = false) {
    index = Math.max(0, Math.min(slides.length - 1, target));
    if (instant) track.style.transition = 'none';
    track.style.transform = `translateX(${-index * 100}%)`;
    if (instant) {
      void track.offsetWidth;
      track.style.transition = '';
    }

    slides.forEach((slide, i) => (i === index ? slide.removeAttribute('inert') : slide.setAttribute('inert', '')));
    document.body.dataset.theme = slides[index].dataset.theme;
    document.querySelector('meta[name="theme-color"]').content = getComputedStyle(slides[index]).backgroundColor;

    $$('.nav a').forEach((link) => {
      if (link.dataset.go === names[index]) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
    $$('.dot').forEach((dot, i) => dot.setAttribute('aria-current', String(i === index)));
    prev.disabled = index === 0;
    next.disabled = index === slides.length - 1;

    history.replaceState(null, '', '#' + names[index]);
    document.title = index === 0 ? document.body.dataset.homeTitle || document.title : `${titleCase(names[index])} | Antor`;
  }

  document.addEventListener('click', (event) => {
    const trigger = event.target.closest('[data-go]');
    if (!trigger) return;
    event.preventDefault();
    const target = names.indexOf(trigger.dataset.go);
    if (target > -1) {
      go(target);
      slides[target].scrollTop = 0;
    }
  });
  prev.addEventListener('click', () => go(index - 1));
  next.addEventListener('click', () => go(index + 1));

  document.addEventListener('keydown', (event) => {
    if (dialogOpen() || event.altKey || event.ctrlKey || event.metaKey) return;
    if (/INPUT|TEXTAREA|SELECT/.test(event.target.tagName)) return;
    if (event.key === 'ArrowRight' || event.key === 'PageDown') go(index + 1);
    else if (event.key === 'ArrowLeft' || event.key === 'PageUp') go(index - 1);
    else if (event.key === 'Home' && event.target === document.body) go(0);
    else if (event.key === 'End' && event.target === document.body) go(slides.length - 1);
  });

  viewport.addEventListener('wheel', (event) => {
    if (dialogOpen() || locked) return;
    const horizontal = Math.abs(event.deltaX) > Math.abs(event.deltaY);
    const delta = horizontal ? event.deltaX : event.deltaY;
    if (Math.abs(delta) < 25) return;
    const slide = slides[index];
    if (!horizontal && slide.scrollHeight > slide.clientHeight + 4) return; // tall content scrolls normally
    locked = true;
    setTimeout(() => { locked = false; }, 850);
    go(index + (delta > 0 ? 1 : -1));
  }, { passive: true });

  let startX = 0;
  let startY = 0;
  let startTarget = null;
  viewport.addEventListener('touchstart', (event) => {
    startX = event.touches[0].clientX;
    startY = event.touches[0].clientY;
    startTarget = event.target;
  }, { passive: true });
  viewport.addEventListener('touchend', (event) => {
    if (startTarget?.closest('[data-noswipe]')) return;
    const dx = event.changedTouches[0].clientX - startX;
    const dy = event.changedTouches[0].clientY - startY;
    if (Math.abs(dx) > 55 && Math.abs(dx) > Math.abs(dy) * 1.5) go(index + (dx < 0 ? 1 : -1));
  }, { passive: true });

  // Stops the browser from shifting the hidden container when it scrolls to a #hash.
  viewport.addEventListener('scroll', () => { viewport.scrollLeft = 0; viewport.scrollTop = 0; });
  window.addEventListener('hashchange', () => {
    const target = names.indexOf(location.hash.slice(1));
    if (target > -1 && target !== index) go(target);
  });

  document.body.dataset.homeTitle = document.title;
  const start = names.indexOf(location.hash.slice(1));
  go(start > -1 ? start : 0, true);
  return { go };
}

A.slider = { initSlider };
})(window.Antor = window.Antor || {});
