(function (A) {
'use strict';
const { $, el, putImage } = A.dom;

// Grid ratio choices. "auto" keeps every image's own shape, "random" mixes shapes.
const LAYOUTS = [
  { key: 'auto', label: 'Auto (original)', short: 'Auto' },
  { key: 'random', label: 'Random', short: 'Random' },
  { key: '1/1', label: '1:1 Square', short: '1:1', w: 1, h: 1 },
  { key: '4/3', label: '4:3 Landscape', short: '4:3', w: 4, h: 3 },
  { key: '3/4', label: '3:4 Portrait', short: '3:4', w: 3, h: 4 },
  { key: '3/2', label: '3:2 Landscape', short: '3:2', w: 3, h: 2 },
  { key: '2/3', label: '2:3 Portrait', short: '2:3', w: 2, h: 3 },
  { key: '4/5', label: '4:5 Portrait', short: '4:5', w: 4, h: 5 },
  { key: '16/9', label: '16:9 Wide', short: '16:9', w: 16, h: 9 },
  { key: '9/16', label: '9:16 Tall', short: '9:16', w: 9, h: 16 }
];
const RANDOM_POOL = LAYOUTS.filter((l) => l.w && ['1/1', '4/3', '3/4', '3/2', '2/3', '4/5', '16/9'].includes(l.key));
const STORAGE_KEY = 'antor.gridRatio';

const RANDOM_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="5.5" height="9" rx="1.2"/><rect x="9.5" y="4" width="5.5" height="16" rx="1.2"/><rect x="16" y="4" width="5" height="6" rx="1.2"/></svg>';

function readSaved() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return LAYOUTS.some((l) => l.key === saved) ? saved : 'auto';
  } catch { return 'auto'; }
}
function save(key) {
  try { localStorage.setItem(STORAGE_KEY, key); } catch { /* private mode: ignore */ }
}

function layoutIcon(layout) {
  const icon = el('span', { class: 'ratio-icon', 'aria-hidden': 'true' });
  if (layout.key === 'auto') {
    icon.classList.add('is-auto');
    icon.append(el('i'));
  } else if (layout.key === 'random') {
    icon.innerHTML = RANDOM_ICON; // static, trusted markup
  } else {
    const box = el('i');
    const scale = 22 / Math.max(layout.w, layout.h);
    box.style.width = `${Math.round(layout.w * scale)}px`;
    box.style.height = `${Math.round(layout.h * scale)}px`;
    icon.append(box);
  }
  return icon;
}

function renderPortfolio({ categories, projects }) {
  const labels = new Map(categories.map((c) => [c.key, c.label]));
  const chips = $('#chips');
  const grid = $('#grid');
  const lightbox = $('#lightbox');
  const layoutBox = $('#layout');
  const layoutBtn = $('#layout-btn');
  const layoutMenu = $('#layout-menu');
  const layoutLabel = $('#layout-label');

  let filter = 'all';
  let layout = readSaved();
  let randomRatios = new Map();

  const usedCategories = categories.filter((c) => projects.some((p) => p.category === c.key));

  function shuffleRatios() {
    randomRatios = new Map(projects.map((p) => [p.id, RANDOM_POOL[Math.floor(Math.random() * RANDOM_POOL.length)]]));
  }

  function drawChips() {
    chips.replaceChildren(
      ...[{ key: 'all', label: 'All' }, ...usedCategories].map((c) =>
        el('button', {
          class: 'chip', type: 'button', 'aria-pressed': String(c.key === filter),
          onclick: () => { filter = c.key; drawChips(); drawGrid(); }
        }, c.label))
    );
  }

  function drawGrid() {
    const shown = projects.filter((p) => filter === 'all' || p.category === filter);
    const fixed = LAYOUTS.find((l) => l.key === layout && l.w);
    grid.classList.toggle('is-uniform', Boolean(fixed));
    if (fixed) grid.style.setProperty('--ratio', `${fixed.w} / ${fixed.h}`);
    else grid.style.removeProperty('--ratio');

    if (!shown.length) {
      grid.replaceChildren(el('p', { class: 'empty' }, 'Projects are coming soon.'));
      return;
    }
    grid.replaceChildren(...shown.map((project) => {
      const media = el('div', { class: 'media' });
      if (layout === 'random') {
        const r = randomRatios.get(project.id) || RANDOM_POOL[0];
        media.style.setProperty('--ratio', `${r.w} / ${r.h}`);
      }
      putImage(media, project.image, project.title);
      return el('button', {
        class: 'tile', type: 'button', 'aria-label': `Open ${project.title}`,
        onclick: () => open(project)
      }, media, el('div', { class: 'cap' }, el('b', {}, project.title), el('span', {}, labels.get(project.category) || '')));
    }));
  }

  // ----- ratio dropdown -----
  function drawMenu() {
    layoutMenu.replaceChildren(...LAYOUTS.map((item) =>
      el('button', {
        type: 'button', role: 'menuitemradio', 'aria-checked': String(item.key === layout),
        onclick: () => choose(item.key)
      }, layoutIcon(item), item.label)));
    layoutLabel.textContent = LAYOUTS.find((l) => l.key === layout).short;
  }

  function openMenu() {
    layoutMenu.hidden = false;
    layoutBtn.setAttribute('aria-expanded', 'true');
    (layoutMenu.querySelector('[aria-checked="true"]') || layoutMenu.firstElementChild).focus();
  }
  function closeMenu(returnFocus = false) {
    layoutMenu.hidden = true;
    layoutBtn.setAttribute('aria-expanded', 'false');
    if (returnFocus) layoutBtn.focus();
  }
  function choose(key) {
    layout = key;
    if (key === 'random') shuffleRatios(); // picking Random again reshuffles
    save(key);
    drawMenu();
    drawGrid();
    closeMenu(true);
  }

  layoutBtn.addEventListener('click', () => (layoutMenu.hidden ? openMenu() : closeMenu()));
  document.addEventListener('click', (event) => {
    if (!layoutMenu.hidden && !layoutBox.contains(event.target)) closeMenu();
  });
  layoutMenu.addEventListener('keydown', (event) => {
    const items = [...layoutMenu.querySelectorAll('button')];
    const i = items.indexOf(document.activeElement);
    if (event.key === 'Escape') { event.preventDefault(); closeMenu(true); }
    else if (event.key === 'ArrowDown') { event.preventDefault(); items[(i + 1) % items.length].focus(); }
    else if (event.key === 'ArrowUp') { event.preventDefault(); items[(i - 1 + items.length) % items.length].focus(); }
    else if (event.key === 'Tab') closeMenu();
    if (event.key.startsWith('Arrow')) event.stopPropagation(); // do not slide pages while using the menu
  });

  function open(project) {
    putImage($('#lb-art'), project.image, project.title);
    $('#lb-title').textContent = project.title;
    $('#lb-cat').textContent = labels.get(project.category) || '';
    lightbox.showModal();
  }

  lightbox.addEventListener('click', (event) => { if (event.target === lightbox) lightbox.close(); });
  if (layout === 'random') shuffleRatios();
  drawChips();
  drawMenu();
  drawGrid();
}

A.portfolio = { renderPortfolio };
})(window.Antor = window.Antor || {});
