(async function (A) {
  'use strict';

  // The slider starts first so navigation works even while content is loading.
  A.slider.initSlider();
  const contact = A.contact.initContact();

  document.addEventListener('click', (event) => {
    const trigger = event.target.closest('[data-contact]');
    if (!trigger) return;
    event.preventDefault();
    contact.open(trigger.dataset.service || '');
  });

  try {
    const { content, live } = await A.api.loadContent();
    A.about.applySettings(content);
    A.portfolio.renderPortfolio(content);
    A.services.renderServices(content);
    contact.setup(content, live);
  } catch (error) {
    console.error(error);
  }
})(window.Antor = window.Antor || {});
