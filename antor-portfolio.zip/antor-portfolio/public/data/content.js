window.ANTOR_CONTENT = {
  "categories": [
    {
      "key": "logo",
      "label": "Logo & branding"
    },
    {
      "key": "social",
      "label": "Social media"
    },
    {
      "key": "banner",
      "label": "Banners"
    },
    {
      "key": "card",
      "label": "Business cards"
    },
    {
      "key": "photo",
      "label": "Photography"
    }
  ],
  "settings": {
    "name": "Antor",
    "role": "Graphic designer & photographer",
    "headline": "I design logos, brands and graphics people remember.",
    "lead": "I’m Antor, a graphic designer and photographer. I make logos, social media designs, banners and business cards that help your business look sharp and get noticed.",
    "aboutTitle": "Hi, I’m Antor.",
    "aboutParagraphs": [
      "I’m a graphic designer who loves clean ideas and bold visuals. I help businesses and creators look professional with logos, social media designs, banners and business cards.",
      "When I’m not designing, I’m out taking photos. I like work that is simple, clear and built to last."
    ],
    "skills": [
      "Logo & branding",
      "Social media design",
      "Banner design",
      "Business card design",
      "Photography"
    ],
    "email": "",
    "photo": "images/antor.jpg",
    "links": {
      "dribbble": "https://dribbble.com/antor_",
      "behance": "https://www.behance.net/antor_",
      "linkedin": "https://www.linkedin.com/in/mahmudullah-antor-6929822b5",
      "instagram": "https://www.instagram.com/antor_photography/"
    }
  },
  "services": [
    {
      "id": "s-logo",
      "name": "Logo & branding",
      "text": "A logo is where a brand starts. I design the mark, colors and typography so your business looks the same and feels trusted everywhere it appears.",
      "items": [
        "Primary logo and variations",
        "Color palette and fonts",
        "Brand guideline",
        "Files ready for print and web"
      ],
      "cta": "Start a logo project",
      "link": "",
      "image": "images/work-01.jpg",
      "category": "logo"
    },
    {
      "id": "s-social",
      "name": "Social media design",
      "text": "Posts, stories and covers that match your brand and stop the scroll. Designed in the right size for each platform.",
      "items": [
        "Post and story designs",
        "Page covers and profile images",
        "Reusable templates",
        "Consistent look across platforms"
      ],
      "cta": "Plan my social media",
      "link": "",
      "image": "images/work-02.jpg",
      "category": "social"
    },
    {
      "id": "s-banner",
      "name": "Banner design",
      "text": "Clear, eye-catching banners for websites, ads, events and print. Short message, strong visual.",
      "items": [
        "Web and ad banners",
        "Facebook and YouTube covers",
        "Event and print banners",
        "Sized for where you will use it"
      ],
      "cta": "Order a banner",
      "link": "",
      "image": "images/work-03.jpg",
      "category": "banner"
    },
    {
      "id": "s-card",
      "name": "Business card design",
      "text": "A business card that people keep. Simple layouts that carry your logo and details with confidence.",
      "items": [
        "Front and back layout",
        "Print-ready files",
        "Matches your brand colors",
        "Digital version if you need it"
      ],
      "cta": "Design my card",
      "link": "",
      "image": "images/work-04.jpg",
      "category": "card"
    },
    {
      "id": "s-other",
      "name": "Other graphics work",
      "text": "If it needs to be designed, I can help. Flyers, posters, brochures, menus, labels and more.",
      "items": [
        "Flyers and posters",
        "Brochures and menus",
        "Packaging and labels",
        "Anything graphics-related"
      ],
      "cta": "Tell me your idea",
      "link": "",
      "image": "images/work-08.jpg",
      "category": "banner"
    },
    {
      "id": "s-photo",
      "name": "Photography",
      "text": "I also take photos. Have a look at my Instagram to see my style and get in touch for a shoot.",
      "items": [
        "Product and lifestyle photos",
        "Portraits",
        "Photo editing and color work"
      ],
      "cta": "See my photography",
      "link": "instagram",
      "image": "images/work-06.jpg",
      "category": "photo"
    }
  ],
  "projects": [
    {
      "id": "p-01",
      "title": "Logo design",
      "category": "logo",
      "image": "images/work-01.jpg"
    },
    {
      "id": "p-02",
      "title": "Social media post",
      "category": "social",
      "image": "images/work-02.jpg"
    },
    {
      "id": "p-03",
      "title": "Web banner",
      "category": "banner",
      "image": "images/work-03.jpg"
    },
    {
      "id": "p-04",
      "title": "Business card",
      "category": "card",
      "image": "images/work-04.jpg"
    },
    {
      "id": "p-05",
      "title": "Brand identity",
      "category": "logo",
      "image": "images/work-05.jpg"
    },
    {
      "id": "p-06",
      "title": "Landscape photo",
      "category": "photo",
      "image": "images/work-06.jpg"
    },
    {
      "id": "p-07",
      "title": "Story design",
      "category": "social",
      "image": "images/work-07.jpg"
    },
    {
      "id": "p-08",
      "title": "Event banner",
      "category": "banner",
      "image": "images/work-08.jpg"
    },
    {
      "id": "p-09",
      "title": "Business card set",
      "category": "card",
      "image": "images/work-09.jpg"
    },
    {
      "id": "p-10",
      "title": "Portrait photo",
      "category": "photo",
      "image": "images/work-10.jpg"
    }
  ]
};
