import { api } from './api.js';
import { el, field, showErrors, toast, viewHead } from './ui.js';

export async function renderProjects(root) {
  const { projects, categories } = await api('GET', '/admin/projects');
  const labels = new Map(categories.map((c) => [c.key, c.label]));
  let list = projects;

  function draw() {
    const grid = list.length
      ? el('div', { class: 'project-grid' }, list.map((project, i) => card(project, i)))
      : el('div', { class: 'empty' }, 'No projects yet. Click “Add project” to upload your first one.');
    root.replaceChildren(
      viewHead('Projects', el('button', { class: 'btn btn-orange', type: 'button', onclick: () => openEditor() }, 'Add project')),
      el('p', { class: 'muted' }, 'Projects appear on the Portfolio page in this order. Hidden projects are not shown to visitors.'),
      grid
    );
  }

  function card(project, i) {
    return el('article', { class: 'project' },
      el('div', { class: 'thumb' }, el('img', { src: '/' + project.image, alt: project.title, loading: 'lazy' })),
      el('div', { class: 'project-body' },
        el('h3', {}, project.title),
        el('div', { class: 'row' },
          el('span', { class: 'tag' }, labels.get(project.category) || project.category),
          project.visible === false ? el('span', { class: 'tag off' }, 'Hidden') : null),
        el('div', { class: 'row' },
          el('button', { class: 'btn btn-line btn-small', type: 'button', disabled: i === 0, 'aria-label': 'Move up', onclick: () => move(project, 'up') }, 'Up'),
          el('button', { class: 'btn btn-line btn-small', type: 'button', disabled: i === list.length - 1, 'aria-label': 'Move down', onclick: () => move(project, 'down') }, 'Down'),
          el('button', { class: 'btn btn-black btn-small', type: 'button', onclick: () => openEditor(project) }, 'Edit'),
          el('button', { class: 'btn btn-danger btn-small', type: 'button', onclick: () => remove(project) }, 'Delete'))));
  }

  async function move(project, direction) {
    try {
      list = (await api('PATCH', `/admin/projects/${project.id}/move`, { direction })).projects;
      draw();
    } catch (error) { toast(error.message, 'bad'); }
  }

  async function remove(project) {
    if (!confirm(`Delete “${project.title}”? This also deletes its image.`)) return;
    try {
      await api('DELETE', `/admin/projects/${project.id}`);
      list = list.filter((p) => p.id !== project.id);
      draw();
      toast('Project deleted');
    } catch (error) { toast(error.message, 'bad'); }
  }

  function openEditor(project) {
    const editing = Boolean(project);
    const dialog = el('dialog', {});
    const title = el('input', { type: 'text', maxlength: '80', value: project?.title || '' });
    const category = el('select', {}, categories.map((c) => el('option', { value: c.key }, c.label)));
    category.value = project?.category || categories[0].key;
    const file = el('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp,image/gif' });
    const preview = el('img', { class: 'preview', alt: 'Image preview', hidden: !editing, src: editing ? '/' + project.image : null });
    const visible = el('input', { type: 'checkbox' });
    visible.checked = project?.visible !== false;
    const save = el('button', { class: 'btn btn-orange', type: 'submit' }, editing ? 'Save changes' : 'Add project');

    file.addEventListener('change', () => {
      const chosen = file.files[0];
      if (!chosen) return;
      preview.src = URL.createObjectURL(chosen);
      preview.hidden = false;
    });

    const form = el('form', { novalidate: true },
      el('h2', {}, editing ? 'Edit project' : 'Add project'),
      field('Title', title, { name: 'title' }),
      field('Category', category, { name: 'category' }),
      field(editing ? 'New image (optional)' : 'Image', file, { name: 'image', hint: 'JPG, PNG, WebP or GIF, up to 5 MB.' }),
      preview,
      el('label', { class: 'check' }, visible, 'Show on the website'),
      el('div', { class: 'actions' }, save, el('button', { class: 'btn btn-line', type: 'button', onclick: () => dialog.close() }, 'Cancel')));

    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      showErrors(form);
      const data = new FormData();
      data.set('title', title.value);
      data.set('category', category.value);
      data.set('visible', String(visible.checked));
      if (file.files[0]) data.set('image', file.files[0]);
      save.disabled = true;
      try {
        if (editing) {
          const { project: updated } = await api('PUT', `/admin/projects/${project.id}`, data);
          list = list.map((p) => (p.id === updated.id ? updated : p));
        } else {
          const { project: created } = await api('POST', '/admin/projects', data);
          list = [created, ...list];
        }
        dialog.close();
        draw();
        toast(editing ? 'Project updated' : 'Project added');
      } catch (error) {
        showErrors(form, error.errors);
        if (!Object.keys(error.errors).length) toast(error.message, 'bad');
      } finally { save.disabled = false; }
    });

    dialog.append(form);
    dialog.addEventListener('close', () => dialog.remove());
    document.body.append(dialog);
    dialog.showModal();
  }

  draw();
}
