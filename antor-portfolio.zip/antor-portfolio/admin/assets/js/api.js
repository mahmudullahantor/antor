let csrfToken = '';
let onUnauthorized = () => {};

export const setCsrf = (token) => { csrfToken = token; };
export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn; };

/** Calls the backend. `body` can be a plain object (sent as JSON) or FormData (file uploads). */
export async function api(method, path, body) {
  const options = { method, credentials: 'same-origin', headers: { Accept: 'application/json' } };
  if (method !== 'GET') options.headers['X-CSRF-Token'] = csrfToken;
  if (body instanceof FormData) {
    options.body = body;
  } else if (body !== undefined) {
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(body);
  }

  const res = await fetch('/api' + path, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const error = new Error(data.error || `Request failed (${res.status})`);
    error.status = res.status;
    error.errors = data.errors || {};
    if (res.status === 401 && !path.endsWith('/login')) onUnauthorized();
    throw error;
  }
  return data;
}
