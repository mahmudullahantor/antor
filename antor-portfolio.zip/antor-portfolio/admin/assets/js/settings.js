import { api, setCsrf } from './api.js';
import { el, field, showErrors, toast, viewHead } from './ui.js';

const LINKS = [['dribbble', 'Dribbble'], ['behance', 'Behance'], ['linkedin', 'LinkedIn'], ['instagram', 'Instagram']];

export async function renderSettings(root) {
  const { settings } = await api('GET', '/admin/settings');

  const input = (value, attrs = {}) => el('input', { type: 'text', value: value || '', ...attrs });
  const area = (value, rows) => { const t = el('textarea', { rows: String(rows) }); t.value = value || ''; return t; };

  const f = {
    name: input(settings.name, { maxlength: '60' }),
    role: input(settings.role, { maxlength: '80' }),
    headline: input(settings.headline, { maxlength: '140' }),
    lead: area(settings.lead, 3),
    aboutTitle: input(settings.aboutTitle, { maxlength: '80' }),
    about: area(settings.aboutParagraphs.join('\n\n'), 6),
    skills: input(settings.skills.join(', ')),
    email: input(settings.email, { type: 'email', maxlength: '120' }),
    links: Object.fromEntries(LINKS.map(([key]) => [key, input(settings.links[key], { type: 'url' })]))
  };

  const save = el('button', { class: 'btn btn-orange', type: 'submit' }, 'Save changes');
  const siteForm = el('form', { novalidate: true },
    viewHead('Settings', save),
    el('section', { class: 'card' },
      el('h2', {}, 'Home page'),
      el('div', { class: 'form-grid' },
        el('div', { class: 'two' }, field('Your name', f.name, { name: 'name' }), field('Role', f.role, { name: 'role' })),
        field('Main headline', f.headline, { name: 'headline' }),
        field('Intro text', f.lead, { name: 'lead' }))),
    el('section', { class: 'card' },
      el('h2', {}, 'About page'),
      el('div', { class: 'form-grid' },
        field('Title', f.aboutTitle, { name: 'aboutTitle' }),
        field('About text', f.about, { name: 'aboutParagraphs', hint: 'Separate paragraphs with a blank line.' }),
        field('Skills', f.skills, { name: 'skills', hint: 'Separate with commas.' }))),
    el('section', { class: 'card' },
      el('h2', {}, 'Contact and links'),
      el('div', { class: 'form-grid' },
        field('Email', f.email, { name: 'email', hint: 'Shows an “Email me” button. Leave empty to hide it.' }),
        ...LINKS.map(([key, label]) => field(label, f.links[key], { name: `links.${key}` })))));

  siteForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    showErrors(siteForm);
    save.disabled = true;
    try {
      await api('PUT', '/admin/settings', {
        name: f.name.value, role: f.role.value, headline: f.headline.value, lead: f.lead.value,
        aboutTitle: f.aboutTitle.value,
        aboutParagraphs: f.about.value.split(/\n\s*\n/),
        skills: f.skills.value.split(','),
        email: f.email.value,
        links: Object.fromEntries(LINKS.map(([key]) => [key, f.links[key].value]))
      });
      toast('Settings saved');
    } catch (error) {
      showErrors(siteForm, error.errors);
      toast(error.message, 'bad');
    } finally { save.disabled = false; }
  });

  // Profile photo
  const preview = el('img', { alt: 'Current profile photo', src: '/' + settings.photo });
  const photoInput = el('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp,image/gif' });
  const upload = el('button', { class: 'btn btn-black', type: 'button' }, 'Upload photo');
  upload.addEventListener('click', async () => {
    if (!photoInput.files[0]) return toast('Choose a photo first', 'bad');
    const data = new FormData();
    data.set('photo', photoInput.files[0]);
    upload.disabled = true;
    try {
      const { photo } = await api('POST', '/admin/settings/photo', data);
      preview.src = '/' + photo;
      photoInput.value = '';
      toast('Photo updated');
    } catch (error) { toast(error.message, 'bad'); } finally { upload.disabled = false; }
  });
  const photoCard = el('section', { class: 'card' },
    el('h2', {}, 'Profile photo'),
    el('div', { class: 'photo-row' }, preview, el('div', { class: 'form-grid' }, photoInput, upload)));

  // Password
  const current = input('', { type: 'password', autocomplete: 'current-password' });
  const next = input('', { type: 'password', autocomplete: 'new-password' });
  const confirmPw = input('', { type: 'password', autocomplete: 'new-password' });
  const change = el('button', { class: 'btn btn-black', type: 'submit' }, 'Change password');
  const pwForm = el('form', { class: 'card', novalidate: true },
    el('h2', {}, 'Change password'),
    el('div', { class: 'form-grid' },
      field('Current password', current, { name: 'currentPassword' }),
      field('New password', next, { name: 'newPassword', hint: 'At least 10 characters.' }),
      field('Repeat new password', confirmPw, { name: 'confirm' }),
      el('div', { class: 'actions' }, change)));
  pwForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    showErrors(pwForm);
    if (next.value !== confirmPw.value) return showErrors(pwForm, { confirm: 'The passwords do not match.' });
    change.disabled = true;
    try {
      const { csrf } = await api('POST', '/admin/password', { currentPassword: current.value, newPassword: next.value });
      setCsrf(csrf);
      pwForm.reset();
      toast('Password changed. Other devices were signed out.');
    } catch (error) {
      showErrors(pwForm, error.errors);
      if (!Object.keys(error.errors).length) toast(error.message, 'bad');
    } finally { change.disabled = false; }
  });

  root.replaceChildren(siteForm, photoCard, pwForm);
}
