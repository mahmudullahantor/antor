import { api } from './api.js';
import { el, field, showErrors, toast, viewHead } from './ui.js';

const LINK_LABELS = { dribbble: 'Dribbble', behance: 'Behance', linkedin: 'LinkedIn', instagram: 'Instagram' };

export async function renderServices(root) {
  const { services, projects, linkKeys } = await api('GET', '/admin/services');
  let list = services.map((s) => ({ ...s }));
  let form;

  function draw() {
    form = el('form', { novalidate: true },
      viewHead('Services',
        el('button', { class: 'btn btn-line', type: 'button', onclick: add }, 'Add service'),
        el('button', { class: 'btn btn-orange', type: 'submit' }, 'Save changes')),
      el('p', { class: 'muted' }, 'These appear on the Services page. Each service shows the image of the project you choose.'),
      ...list.map((service, i) => editor(service, i)));
    form.addEventListener('submit', save);
    root.replaceChildren(form);
  }

  function editor(service, i) {
    const k = (name) => `services.${i}.${name}`;
    const bind = (input, prop, transform = (v) => v) => {
      input.addEventListener('input', () => { service[prop] = transform(input.value); });
      return input;
    };
    const name = bind(el('input', { type: 'text', maxlength: '60', value: service.name }), 'name');
    const text = bind(el('textarea', { rows: '3', maxlength: '400' }), 'text');
    text.value = service.text;
    const items = bind(el('textarea', { rows: '4' }), 'items', (v) => v.split('\n'));
    items.value = service.items.join('\n');
    const cta = bind(el('input', { type: 'text', maxlength: '40', value: service.cta }), 'cta');
    const project = bind(el('select', {},
      el('option', { value: '' }, 'No image'),
      projects.map((p) => el('option', { value: p.id }, p.title))), 'projectId');
    project.value = service.projectId || '';
    const link = bind(el('select', {},
      el('option', { value: '' }, 'Open the contact form'),
      linkKeys.map((key) => el('option', { value: key }, `Open my ${LINK_LABELS[key]}`))), 'link');
    link.value = service.link || '';

    return el('section', { class: 'card service' },
      el('div', { class: 'service-head' },
        el('strong', {}, service.name || 'New service'),
        el('div', { class: 'row' },
          el('button', { class: 'btn btn-line btn-small', type: 'button', disabled: i === 0, onclick: () => swap(i, i - 1) }, 'Up'),
          el('button', { class: 'btn btn-line btn-small', type: 'button', disabled: i === list.length - 1, onclick: () => swap(i, i + 1) }, 'Down'),
          el('button', { class: 'btn btn-danger btn-small', type: 'button', onclick: () => remove(i) }, 'Remove'))),
      field('Service name', name, { name: k('name') }),
      field('Description', text, { name: k('text') }),
      field('What you get', items, { name: k('items'), hint: 'One item per line, up to 8.' }),
      el('div', { class: 'two' },
        field('Button text', cta, { name: k('cta') }),
        field('Button opens', link, { name: k('link') })),
      field('Picture', project, { name: k('projectId'), hint: 'Uses the image of this project.' }));
  }

  function swap(a, b) {
    [list[a], list[b]] = [list[b], list[a]];
    draw();
  }
  function remove(i) {
    if (!confirm(`Remove “${list[i].name || 'this service'}”?`)) return;
    list.splice(i, 1);
    draw();
  }
  function add() {
    list.push({ id: '', name: '', text: '', items: [], cta: 'Start a project', projectId: '', link: '' });
    draw();
    form.lastElementChild.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  async function save(event) {
    event.preventDefault();
    showErrors(form);
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
      await api('PUT', '/admin/services', { services: list });
      toast('Services saved');
    } catch (error) {
      showErrors(form, error.errors);
      toast(error.message, 'bad');
    } finally { button.disabled = false; }
  }

  draw();
}
