import { api } from './api.js';
import { el, toast, viewHead, formatDate } from './ui.js';

export async function renderMessages(root, { onUnread }) {
  let { messages } = await api('GET', '/admin/messages');

  const unread = () => messages.filter((m) => !m.read).length;

  function draw() {
    onUnread(unread());
    root.replaceChildren(
      viewHead('Messages'),
      messages.length
        ? el('div', {}, messages.map(item))
        : el('div', { class: 'empty' }, 'No messages yet. Messages from your contact form will appear here.'));
  }

  function item(message) {
    const details = el('details', { class: `msg ${message.read ? '' : 'unread'}`.trim() });
    details.addEventListener('toggle', () => { if (details.open && !message.read) setRead(message, true, false); });
    const subject = encodeURIComponent(`Re: ${message.service || 'your message'}`);

    details.append(
      el('summary', {},
        el('span', {}, message.read ? null : el('span', { class: 'dot', 'aria-label': 'Unread' }), el('strong', {}, message.name), ` · ${message.service || 'General question'}`),
        el('span', { class: 'muted' }, formatDate(message.createdAt))),
      el('div', { class: 'msg-body' },
        el('div', {}, el('a', { href: `mailto:${message.email}?subject=${subject}` }, message.email)),
        el('div', { class: 'msg-text' }, message.message),
        el('div', { class: 'actions' },
          el('a', { class: 'btn btn-orange btn-small', href: `mailto:${message.email}?subject=${subject}` }, 'Reply by email'),
          el('button', { class: 'btn btn-line btn-small', type: 'button', onclick: () => setRead(message, !message.read, true) }, message.read ? 'Mark as unread' : 'Mark as read'),
          el('button', { class: 'btn btn-danger btn-small', type: 'button', onclick: () => remove(message) }, 'Delete'))));
    return details;
  }

  async function setRead(message, read, redraw) {
    try {
      await api('PATCH', `/admin/messages/${message.id}`, { read });
      message.read = read;
      onUnread(unread());
      if (redraw) draw();
    } catch (error) { toast(error.message, 'bad'); }
  }

  async function remove(message) {
    if (!confirm(`Delete the message from ${message.name}?`)) return;
    try {
      await api('DELETE', `/admin/messages/${message.id}`);
      messages = messages.filter((m) => m.id !== message.id);
      draw();
      toast('Message deleted');
    } catch (error) { toast(error.message, 'bad'); }
  }

  draw();
}
