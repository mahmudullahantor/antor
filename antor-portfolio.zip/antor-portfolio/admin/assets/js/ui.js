export const $ = (selector, root = document) => root.querySelector(selector);

/** Builds an element safely: text is always inserted as text, never as HTML. */
export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value == null || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'value') node.value = value;
    else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value === true ? '' : value);
  }
  for (const child of children.flat()) {
    if (child == null || child === false) continue;
    node.append(child.nodeType ? child : document.createTextNode(String(child)));
  }
  return node;
}

let toastTimer;
export function toast(message, kind = '') {
  const node = $('#toast');
  node.textContent = message;
  node.className = `toast show ${kind}`.trim();
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { node.className = 'toast'; }, 3200);
}

/** A labelled input with an error line underneath. `name` links it to server error messages. */
export function field(label, input, { name, hint } = {}) {
  if (name) input.name = name;
  return el('label', { class: 'field' }, label, input, hint ? el('span', { class: 'hint' }, hint) : null,
    el('span', { class: 'err', 'data-err': name || '' }));
}

export function showErrors(root, errors = {}) {
  root.querySelectorAll('[data-err]').forEach((node) => {
    const message = errors[node.dataset.err] || '';
    node.textContent = message;
    node.parentElement.querySelector('input,select,textarea')?.setAttribute('aria-invalid', String(Boolean(message)));
  });
}

export const formatDate = (iso) =>
  new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });

export function viewHead(title, ...actions) {
  return el('div', { class: 'view-head' }, el('h1', {}, title), el('div', { class: 'actions' }, actions));
}
