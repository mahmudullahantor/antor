import { api, setCsrf, setUnauthorizedHandler } from './api.js';
import { $ } from './ui.js';
import { renderProjects } from './projects.js';
import { renderServices } from './services.js';
import { renderMessages } from './messages.js';
import { renderSettings } from './settings.js';

const views = { projects: renderProjects, services: renderServices, messages: renderMessages, settings: renderSettings };
const loginScreen = $('#login-screen');
const app = $('#app');
const view = $('#view');

function setUnread(count) {
  const badge = $('#unread-badge');
  badge.textContent = String(count);
  badge.hidden = count === 0;
}

async function show(name) {
  const key = views[name] ? name : 'projects';
  document.querySelectorAll('[data-view]').forEach((button) => {
    if (button.dataset.view === key) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
  history.replaceState(null, '', '#' + key);
  view.replaceChildren();
  try {
    await views[key](view, { onUnread: setUnread });
  } catch (error) {
    if (error.status !== 401) view.textContent = error.message;
  }
}

async function refreshUnread() {
  try { setUnread((await api('GET', '/admin/messages')).unread); } catch { /* ignored */ }
}

function showLogin() {
  app.hidden = true;
  loginScreen.hidden = false;
  $('#login-form').elements.username.focus();
}

async function showApp() {
  loginScreen.hidden = true;
  app.hidden = false;
  await show(location.hash.slice(1));
  refreshUnread();
}

setUnauthorizedHandler(showLogin);

document.querySelectorAll('[data-view]').forEach((button) =>
  button.addEventListener('click', () => show(button.dataset.view)));

$('#login-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const error = $('#login-error');
  error.textContent = '';
  try {
    const session = await api('POST', '/admin/login', {
      username: form.elements.username.value,
      password: form.elements.password.value
    });
    setCsrf(session.csrf);
    form.reset();
    await showApp();
  } catch (err) {
    error.textContent = err.message;
  }
});

$('#logout').addEventListener('click', async () => {
  try { await api('POST', '/admin/logout', {}); } catch { /* ignore */ }
  setCsrf('');
  showLogin();
});

const session = await api('GET', '/admin/session');
if (session.authenticated) {
  setCsrf(session.csrf);
  await showApp();
} else {
  showLogin();
}
