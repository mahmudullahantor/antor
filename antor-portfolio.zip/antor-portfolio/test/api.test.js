process.env.LOG_LEVEL = 'silent';

import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { buildConfig } from '../server/config.js';
import { startServer } from '../server/bootstrap.js';

// A valid 1x1 PNG
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const PASSWORD = 'correct-horse-battery';

let app, base, tmp;

before(async () => {
  tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'antor-test-'));
  const config = buildConfig({
    port: 0, host: '127.0.0.1', isProd: false, cookieSecure: false,
    sessionSecret: 'test-secret-'.padEnd(40, 'x'),
    adminUser: 'admin', adminPassword: PASSWORD,
    dataDir: path.join(tmp, 'data'), uploadsDir: path.join(tmp, 'uploads')
  });
  app = await startServer(config);
  base = `http://127.0.0.1:${app.port}`;
});

after(async () => {
  await app.close();
  await fs.rm(tmp, { recursive: true, force: true });
});

const json = (body) => ({ headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

async function login() {
  const res = await fetch(`${base}/api/admin/login`, { method: 'POST', ...json({ username: 'admin', password: PASSWORD }) });
  assert.equal(res.status, 200);
  const { csrf } = await res.json();
  const cookie = res.headers.get('set-cookie').split(';')[0];
  return { cookie, csrf };
}
const authed = (s, extra = {}) => ({ ...extra, headers: { ...(extra.headers || {}), Cookie: s.cookie, 'X-CSRF-Token': s.csrf } });

test('serves the website and public content', async () => {
  const page = await fetch(base + '/');
  assert.equal(page.status, 200);
  assert.match(await page.text(), /<html/i);
  const content = await (await fetch(base + '/api/content')).json();
  assert.ok(content.projects.length >= 10);
  assert.ok(content.categories.length === 5);
  assert.equal(content.settings.name, 'Antor');
});

test('blocks path traversal and dotfiles', async () => {
  assert.equal((await fetch(base + '/..%2f..%2fserver%2fconfig.js')).status, 404);
  assert.equal((await fetch(base + '/%2e%2e/server/config.js')).status, 404);
  assert.equal((await fetch(base + '/uploads/.gitkeep')).status, 404);
});

test('security headers are present', async () => {
  const res = await fetch(base + '/');
  assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
});

test('contact form validates, stores and ignores bots', async () => {
  const bad = await fetch(`${base}/api/contact`, { method: 'POST', ...json({ name: 'A', email: 'nope', message: 'short' }) });
  assert.equal(bad.status, 422);
  const errors = (await bad.json()).errors;
  assert.ok(errors.name && errors.email && errors.message);

  const bot = await fetch(`${base}/api/contact`, { method: 'POST', ...json({ name: 'Bot', email: 'b@b.com', message: 'buy cheap stuff now', website: 'http://spam' }) });
  assert.equal(bot.status, 201);

  const ok = await fetch(`${base}/api/contact`, { method: 'POST', ...json({ name: 'Rahim', email: 'rahim@example.com', service: 'Logo & branding', message: 'I need a logo for my shop.' }) });
  assert.equal(ok.status, 201);

  const s = await login();
  const { messages, unread } = await (await fetch(`${base}/api/admin/messages`, authed(s))).json();
  assert.equal(messages.length, 1);
  assert.equal(unread, 1);
  assert.equal(messages[0].name, 'Rahim');
});

test('contact form is rate limited', async () => {
  let last;
  for (let i = 0; i < 7; i++) {
    last = await fetch(`${base}/api/contact`, { method: 'POST', ...json({ name: 'Spammer', email: 's@example.com', message: 'message number ' + i + ' hello' }) });
  }
  assert.equal(last.status, 429);
  assert.ok(last.headers.get('retry-after'));
});

test('admin routes need a session and a CSRF token', async () => {
  assert.equal((await fetch(`${base}/api/admin/projects`)).status, 401);
  const wrong = await fetch(`${base}/api/admin/login`, { method: 'POST', ...json({ username: 'admin', password: 'wrong-password' }) });
  assert.equal(wrong.status, 401);

  const s = await login();
  const noToken = await fetch(`${base}/api/admin/settings`, { method: 'PUT', headers: { Cookie: s.cookie, 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(noToken.status, 403);

  const crossOrigin = await fetch(`${base}/api/admin/logout`, { method: 'POST', headers: { Origin: 'https://evil.example', 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(crossOrigin.status, 403);
});

test('projects: upload, list publicly, hide, reorder and delete', async () => {
  const s = await login();
  const form = new FormData();
  form.set('title', 'Test logo');
  form.set('category', 'logo');
  form.set('image', new Blob([PNG], { type: 'image/png' }), 'x.png');
  const created = await fetch(`${base}/api/admin/projects`, authed(s, { method: 'POST', body: form }));
  assert.equal(created.status, 201);
  const { project } = await created.json();
  assert.match(project.image, /^uploads\/[a-f0-9]+\.png$/);

  let pub = await (await fetch(base + '/api/content')).json();
  assert.equal(pub.projects[0].id, project.id);
  const img = await fetch(`${base}/${project.image}`);
  assert.equal(img.status, 200);
  assert.equal(img.headers.get('content-type'), 'image/png');

  const hideForm = new FormData();
  hideForm.set('title', 'Test logo');
  hideForm.set('category', 'logo');
  hideForm.set('visible', 'false');
  assert.equal((await fetch(`${base}/api/admin/projects/${project.id}`, authed(s, { method: 'PUT', body: hideForm }))).status, 200);
  pub = await (await fetch(base + '/api/content')).json();
  assert.ok(!pub.projects.some((p) => p.id === project.id));

  const moved = await fetch(`${base}/api/admin/projects/${project.id}/move`, authed(s, { method: 'PATCH', ...json({ direction: 'down' }) , headers: { 'Content-Type': 'application/json' } }));
  assert.equal(moved.status, 200);

  assert.equal((await fetch(`${base}/api/admin/projects/${project.id}`, authed(s, { method: 'DELETE' }))).status, 200);
  assert.equal((await fetch(`${base}/${project.image}`)).status, 404);
});

test('rejects uploads that are not images', async () => {
  const s = await login();
  const form = new FormData();
  form.set('title', 'Not an image');
  form.set('category', 'logo');
  form.set('image', new Blob(['<script>alert(1)</script>'], { type: 'image/png' }), 'evil.png');
  const res = await fetch(`${base}/api/admin/projects`, authed(s, { method: 'POST', body: form }));
  assert.equal(res.status, 415);
});

test('settings and services can be updated', async () => {
  const s = await login();
  const { settings } = await (await fetch(`${base}/api/admin/settings`, authed(s))).json();
  const put = await fetch(`${base}/api/admin/settings`, authed(s, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...settings, name: 'Antor Mahmud', email: 'hello@example.com' }) }));
  assert.equal(put.status, 200);
  const badLink = await fetch(`${base}/api/admin/settings`, authed(s, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...settings, links: { ...settings.links, behance: 'javascript:alert(1)' } }) }));
  assert.equal(badLink.status, 422);

  const { services } = await (await fetch(`${base}/api/admin/services`, authed(s))).json();
  services[0].name = 'Brand identity';
  const sp = await fetch(`${base}/api/admin/services`, authed(s, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ services }) }));
  assert.equal(sp.status, 200);
  const pub = await (await fetch(base + '/api/content')).json();
  assert.equal(pub.settings.name, 'Antor Mahmud');
  assert.equal(pub.services[0].name, 'Brand identity');
});

test('changing the password signs out other sessions', async () => {
  const a = await login();
  await new Promise((r) => setTimeout(r, 5));
  const res = await fetch(`${base}/api/admin/password`, authed(a, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ currentPassword: PASSWORD, newPassword: 'a-brand-new-password' }) }));
  assert.equal(res.status, 200);
  assert.equal((await fetch(`${base}/api/admin/projects`, authed(a))).status, 401);
  const relog = await fetch(`${base}/api/admin/login`, { method: 'POST', ...json({ username: 'admin', password: 'a-brand-new-password' }) });
  assert.equal(relog.status, 200);
});
