// Resets the admin username and password.
// Usage:  npm run create-admin -- <username> <new-password>
// Stop the server first, then start it again afterwards.
import path from 'node:path';
import { buildConfig } from '../server/config.js';
import { Database } from '../server/lib/db.js';
import { hashPassword } from '../server/lib/security.js';

const [username, password] = process.argv.slice(2);
if (!username || !password || password.length < 10) {
  console.error('Usage: npm run create-admin -- <username> <password with at least 10 characters>');
  process.exit(1);
}

const config = buildConfig({ sessionSecret: 'x'.repeat(32) });
const db = await new Database(path.join(config.dataDir, 'db.json')).init({});
const passwordHash = await hashPassword(password);
await db.mutate((data) => {
  data.admin = { username, passwordHash, sessionsValidAfter: Date.now() };
});
console.log(`Admin account saved. Username: ${username}`);
