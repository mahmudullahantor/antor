// Creates a static copy of your content for hosting on GitHub Pages (no backend).
//   1. Writes public/data/content.json and content.js from your database (or the seed data on a fresh install)
//   2. Copies uploaded images into public/uploads
// Then publish the "public" folder. The contact form and admin panel need the Node server.
import fs from 'node:fs/promises';
import path from 'node:path';
import { buildConfig } from '../server/config.js';
import { buildPublicContent } from '../server/lib/content.js';

const config = buildConfig({ sessionSecret: 'x'.repeat(32) });
const dbFile = path.join(config.dataDir, 'db.json');
const seedFile = path.join(config.root, 'server', 'seed', 'content.json');

let source = dbFile;
try { await fs.access(dbFile); } catch { source = seedFile; }
const data = JSON.parse(await fs.readFile(source, 'utf8'));

await fs.mkdir(path.join(config.publicDir, 'data'), { recursive: true });
const content = JSON.stringify(buildPublicContent(data), null, 2);
await fs.writeFile(path.join(config.publicDir, 'data', 'content.json'), content);
// content.js lets the site work when index.html is opened directly from a folder (no web server).
await fs.writeFile(path.join(config.publicDir, 'data', 'content.js'), `window.ANTOR_CONTENT = ${content};\n`);

let copied = 0;
try {
  const files = (await fs.readdir(config.uploadsDir)).filter((name) => !name.startsWith('.'));
  await fs.mkdir(path.join(config.publicDir, 'uploads'), { recursive: true });
  for (const name of files) {
    await fs.copyFile(path.join(config.uploadsDir, name), path.join(config.publicDir, 'uploads', name));
    copied++;
  }
} catch { /* no uploads yet */ }

console.log(`Static content written from ${path.basename(source)}. ${copied} uploaded image(s) copied.`);
