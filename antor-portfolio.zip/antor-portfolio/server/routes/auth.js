import { sendJson, readJson, HttpError } from '../lib/http.js';
import { Form } from '../lib/validate.js';
import { hashPassword, verifyPassword, safeEqual, DUMMY_HASH } from '../lib/security.js';
import { issueSession, clearSession, readSession } from '../lib/session.js';
import { requireAdmin } from '../lib/guards.js';

export function authRoutes(router, { limiters }) {
  router.get('/api/admin/session', (ctx) => {
    const session = readSession(ctx.req, ctx.config, ctx.db);
    if (!session) return sendJson(ctx.res, 200, { authenticated: false });
    sendJson(ctx.res, 200, { authenticated: true, user: session.u, csrf: session.csrf });
  });

  router.post('/api/admin/login', async (ctx) => {
    const limit = limiters.login.check(ctx.ip);
    if (!limit.ok) {
      throw new HttpError(429, 'Too many failed attempts. Please wait a few minutes and try again.', { retryAfter: limit.retryAfter });
    }
    const body = await readJson(ctx.req);
    const admin = ctx.db.get().admin;
    const username = typeof body.username === 'string' ? body.username.trim() : '';
    const password = typeof body.password === 'string' ? body.password : '';

    const userMatches = Boolean(admin) && safeEqual(username, admin.username);
    const passwordMatches = await verifyPassword(password, userMatches ? admin.passwordHash : DUMMY_HASH);
    if (!userMatches || !passwordMatches) {
      limiters.login.hit(ctx.ip);
      throw new HttpError(401, 'Wrong username or password.');
    }

    limiters.login.reset(ctx.ip);
    const session = issueSession(ctx.res, ctx.config, admin.username);
    sendJson(ctx.res, 200, { authenticated: true, user: session.u, csrf: session.csrf });
  });

  router.post('/api/admin/logout', (ctx) => {
    clearSession(ctx.res, ctx.config);
    sendJson(ctx.res, 200, { ok: true });
  });

  router.post('/api/admin/password', requireAdmin, async (ctx) => {
    const body = await readJson(ctx.req);
    const admin = ctx.db.get().admin;
    const form = new Form();

    const current = typeof body.currentPassword === 'string' ? body.currentPassword : '';
    const next = typeof body.newPassword === 'string' ? body.newPassword : '';
    if (!(await verifyPassword(current, admin.passwordHash))) form.fail('currentPassword', 'Your current password is not correct.');
    if (next.length < 10) form.fail('newPassword', 'Use at least 10 characters.');
    if (next.length > 200) form.fail('newPassword', 'That password is too long.');
    form.done();

    const passwordHash = await hashPassword(next);
    await ctx.db.mutate((data) => {
      data.admin.passwordHash = passwordHash;
      data.admin.sessionsValidAfter = Date.now(); // signs out every other device
    });
    const session = issueSession(ctx.res, ctx.config, admin.username);
    sendJson(ctx.res, 200, { ok: true, csrf: session.csrf });
  });
}
