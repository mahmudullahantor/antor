import crypto from 'node:crypto';
import { sendJson, readJson, HttpError } from '../lib/http.js';
import { Form } from '../lib/validate.js';
import { buildPublicContent } from '../lib/content.js';
import { LIMITS } from '../constants.js';

export function publicRoutes(router, { limiters }) {
  router.get('/api/health', (ctx) => sendJson(ctx.res, 200, { ok: true }));

  router.get('/api/content', (ctx) => sendJson(ctx.res, 200, buildPublicContent(ctx.db.get())));

  router.post('/api/contact', async (ctx) => {
    const limit = limiters.contact.check(ctx.ip);
    if (!limit.ok) {
      throw new HttpError(429, 'You have sent a few messages already. Please try again later.', { retryAfter: limit.retryAfter });
    }

    const body = await readJson(ctx.req);

    // Honeypot: real visitors never fill this hidden field. Pretend success so bots move on.
    if (typeof body.website === 'string' && body.website.trim()) {
      return sendJson(ctx.res, 201, { ok: true });
    }

    const form = new Form();
    const message = {
      id: crypto.randomBytes(6).toString('hex'),
      name: form.text('name', body.name, { label: 'Name', min: 2, max: 80, required: true }),
      email: form.email('email', body.email),
      service: form.text('service', body.service, { label: 'Service', max: 80 }),
      message: form.text('message', body.message, { label: 'Message', min: 10, max: 2000, required: true, multiline: true }),
      createdAt: new Date().toISOString(),
      read: false
    };
    form.done();

    limiters.contact.hit(ctx.ip);
    await ctx.db.mutate((data) => {
      data.messages.unshift(message);
      data.messages = data.messages.slice(0, LIMITS.maxMessages);
    });
    sendJson(ctx.res, 201, { ok: true });
  });
}
