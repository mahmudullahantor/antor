import crypto from 'node:crypto';
import { sendJson, readJson, readForm, HttpError } from '../lib/http.js';
import { requireAdmin } from '../lib/guards.js';
import { Form } from '../lib/validate.js';
import { saveImage, removeUpload } from '../lib/upload.js';
import { CATEGORIES, LINK_KEYS, LIMITS } from '../constants.js';

const CATEGORY_KEYS = CATEGORIES.map((c) => c.key);
const newId = (prefix) => `${prefix}-${crypto.randomBytes(4).toString('hex')}`;

export function adminRoutes(router) {
  const guard = requireAdmin;
  const formLimit = (ctx) => ctx.config.maxUploadBytes + 64 * 1024;

  // ---------- Projects ----------
  router.get('/api/admin/projects', guard, (ctx) => {
    sendJson(ctx.res, 200, { projects: ctx.db.get().projects, categories: CATEGORIES });
  });

  async function readProjectForm(ctx, { creating }) {
    const { fields, files } = await readForm(ctx.req, formLimit(ctx));
    const form = new Form();
    const project = {
      title: form.text('title', fields.title, { label: 'Title', min: 2, max: 80, required: true }),
      category: form.oneOf('category', fields.category, CATEGORY_KEYS, 'Choose a category.'),
      visible: fields.visible === undefined ? true : form.bool(fields.visible)
    };
    const image = files.find((file) => file.field === 'image');
    if (creating && !image) form.fail('image', 'Please choose an image.');
    form.done();
    return { project, image };
  }

  router.post('/api/admin/projects', guard, async (ctx) => {
    if (ctx.db.get().projects.length >= LIMITS.maxProjects) throw new HttpError(409, 'You reached the project limit.');
    const { project, image } = await readProjectForm(ctx, { creating: true });
    const saved = { id: newId('p'), ...project, image: await saveImage(ctx.config, image) };
    await ctx.db.mutate((data) => { data.projects.unshift(saved); });
    sendJson(ctx.res, 201, { project: saved });
  });

  router.put('/api/admin/projects/:id', guard, async (ctx) => {
    const { project, image } = await readProjectForm(ctx, { creating: false });
    if (!ctx.db.get().projects.some((p) => p.id === ctx.params.id)) throw new HttpError(404, 'Project not found.');
    const newImage = image ? await saveImage(ctx.config, image) : null;

    let oldImage = null;
    const updated = await ctx.db.mutate((data) => {
      const target = data.projects.find((p) => p.id === ctx.params.id);
      if (!target) throw new HttpError(404, 'Project not found.');
      Object.assign(target, project);
      if (newImage) {
        oldImage = target.image;
        target.image = newImage;
      }
      return target;
    });
    if (oldImage) await removeUpload(ctx.config, oldImage);
    sendJson(ctx.res, 200, { project: updated });
  });

  router.patch('/api/admin/projects/:id/move', guard, async (ctx) => {
    const { direction } = await readJson(ctx.req);
    if (!['up', 'down'].includes(direction)) throw new HttpError(422, 'Direction must be "up" or "down".');
    const projects = await ctx.db.mutate((data) => {
      const i = data.projects.findIndex((p) => p.id === ctx.params.id);
      if (i === -1) throw new HttpError(404, 'Project not found.');
      const j = direction === 'up' ? i - 1 : i + 1;
      if (j >= 0 && j < data.projects.length) [data.projects[i], data.projects[j]] = [data.projects[j], data.projects[i]];
      return data.projects;
    });
    sendJson(ctx.res, 200, { projects });
  });

  router.delete('/api/admin/projects/:id', guard, async (ctx) => {
    let removed = null;
    await ctx.db.mutate((data) => {
      const i = data.projects.findIndex((p) => p.id === ctx.params.id);
      if (i === -1) throw new HttpError(404, 'Project not found.');
      [removed] = data.projects.splice(i, 1);
      data.services.forEach((s) => { if (s.projectId === removed.id) s.projectId = ''; });
    });
    await removeUpload(ctx.config, removed.image);
    sendJson(ctx.res, 200, { ok: true });
  });

  // ---------- Services ----------
  router.get('/api/admin/services', guard, (ctx) => {
    const { services, projects } = ctx.db.get();
    sendJson(ctx.res, 200, {
      services,
      projects: projects.map(({ id, title, image }) => ({ id, title, image })),
      linkKeys: LINK_KEYS
    });
  });

  router.put('/api/admin/services', guard, async (ctx) => {
    const body = await readJson(ctx.req, 256 * 1024);
    const input = Array.isArray(body.services) ? body.services : [];
    if (input.length > LIMITS.maxServices) throw new HttpError(422, `You can add up to ${LIMITS.maxServices} services.`);
    const projectIds = new Set(ctx.db.get().projects.map((p) => p.id));

    const form = new Form();
    const services = input.map((raw, i) => {
      const key = (name) => `services.${i}.${name}`;
      const id = typeof raw.id === 'string' && /^[a-z0-9-]{3,40}$/.test(raw.id) ? raw.id : newId('s');
      return {
        id,
        name: form.text(key('name'), raw.name, { label: 'Name', min: 2, max: 60, required: true }),
        text: form.text(key('text'), raw.text, { label: 'Description', max: 400, multiline: true }),
        items: form.list(key('items'), raw.items, { label: 'List', maxItems: 8, maxLength: 80 }),
        cta: form.text(key('cta'), raw.cta, { label: 'Button text', max: 40, required: true }),
        projectId: projectIds.has(raw.projectId) ? raw.projectId : '',
        link: raw.link ? form.oneOf(key('link'), raw.link, LINK_KEYS, 'Choose a valid link.') : ''
      };
    });
    form.done();

    await ctx.db.mutate((data) => { data.services = services; });
    sendJson(ctx.res, 200, { services });
  });

  // ---------- Settings ----------
  router.get('/api/admin/settings', guard, (ctx) => {
    sendJson(ctx.res, 200, { settings: ctx.db.get().settings });
  });

  router.put('/api/admin/settings', guard, async (ctx) => {
    const body = await readJson(ctx.req, 128 * 1024);
    const form = new Form();
    const links = {};
    for (const key of LINK_KEYS) links[key] = form.url(`links.${key}`, body.links?.[key], 'This link');

    const incoming = {
      name: form.text('name', body.name, { label: 'Name', min: 1, max: 60, required: true }),
      role: form.text('role', body.role, { label: 'Role', max: 80 }),
      headline: form.text('headline', body.headline, { label: 'Headline', max: 140, required: true }),
      lead: form.text('lead', body.lead, { label: 'Intro text', max: 400, multiline: true }),
      aboutTitle: form.text('aboutTitle', body.aboutTitle, { label: 'About title', max: 80 }),
      aboutParagraphs: form.list('aboutParagraphs', body.aboutParagraphs, { label: 'About text', maxItems: 4, maxLength: 800 }),
      skills: form.list('skills', body.skills, { label: 'Skills', maxItems: 12, maxLength: 40 }),
      email: form.email('email', body.email, { required: false }),
      links
    };
    form.done();

    const settings = await ctx.db.mutate((data) => {
      data.settings = { ...data.settings, ...incoming };
      return data.settings;
    });
    sendJson(ctx.res, 200, { settings });
  });

  router.post('/api/admin/settings/photo', guard, async (ctx) => {
    const { files } = await readForm(ctx.req, formLimit(ctx));
    const file = files.find((f) => f.field === 'photo');
    if (!file) throw new HttpError(422, 'Please choose a photo.', { errors: { photo: 'Please choose a photo.' } });
    const photo = await saveImage(ctx.config, file);

    let previous = '';
    await ctx.db.mutate((data) => {
      previous = data.settings.photo;
      data.settings.photo = photo;
    });
    await removeUpload(ctx.config, previous);
    sendJson(ctx.res, 200, { photo });
  });

  // ---------- Messages ----------
  router.get('/api/admin/messages', guard, (ctx) => {
    const messages = ctx.db.get().messages;
    sendJson(ctx.res, 200, { messages, unread: messages.filter((m) => !m.read).length });
  });

  router.patch('/api/admin/messages/:id', guard, async (ctx) => {
    const body = await readJson(ctx.req);
    const read = new Form().bool(body.read);
    const message = await ctx.db.mutate((data) => {
      const target = data.messages.find((m) => m.id === ctx.params.id);
      if (!target) throw new HttpError(404, 'Message not found.');
      target.read = read;
      return target;
    });
    sendJson(ctx.res, 200, { message });
  });

  router.delete('/api/admin/messages/:id', guard, async (ctx) => {
    await ctx.db.mutate((data) => {
      const i = data.messages.findIndex((m) => m.id === ctx.params.id);
      if (i === -1) throw new HttpError(404, 'Message not found.');
      data.messages.splice(i, 1);
    });
    sendJson(ctx.res, 200, { ok: true });
  });
}
