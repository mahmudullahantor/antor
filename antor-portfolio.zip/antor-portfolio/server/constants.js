// Values shared by the API, the seed data and the front-end payload.

export const CATEGORIES = [
  { key: 'logo', label: 'Logo & branding' },
  { key: 'social', label: 'Social media' },
  { key: 'banner', label: 'Banners' },
  { key: 'card', label: 'Business cards' },
  { key: 'photo', label: 'Photography' }
];

export const LINK_KEYS = ['dribbble', 'behance', 'linkedin', 'instagram'];

export const LIMITS = {
  maxMessages: 500,
  maxServices: 12,
  maxProjects: 100
};
