import { Router } from './lib/router.js';
import { HttpError } from './lib/errors.js';
import { sendJson, sendRedirect, clientIp } from './lib/http.js';
import { serveStatic } from './lib/static.js';
import { securityHeaders } from './lib/security.js';
import { RateLimiter } from './lib/rate-limit.js';
import { log } from './lib/logger.js';
import { publicRoutes } from './routes/public.js';
import { authRoutes } from './routes/auth.js';
import { adminRoutes } from './routes/admin.js';

const NOT_FOUND_PAGE = `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Page not found</title><body style="font-family:system-ui,sans-serif;display:grid;place-items:center;min-height:100vh;margin:0"><main style="text-align:center"><h1>Page not found</h1><p><a href="/">Go to the home page</a></p></main></body></html>`;

/** Builds the Node request handler. Pass it to http.createServer(). */
export function createApp({ config, db }) {
  const router = new Router();
  const limiters = {
    login: new RateLimiter({ windowMs: 15 * 60 * 1000, max: 8 }),
    contact: new RateLimiter({ windowMs: 60 * 60 * 1000, max: 5 })
  };
  const deps = { config, db, limiters };
  publicRoutes(router, deps);
  authRoutes(router, deps);
  adminRoutes(router, deps);

  async function handleApi(req, res, url) {
    // Extra CSRF defense: browsers send Origin on cross-site writes. It must match this site.
    const origin = req.headers.origin;
    if (origin && !['GET', 'HEAD'].includes(req.method)) {
      let host = '';
      try { host = new URL(origin).host; } catch { /* invalid origin */ }
      if (host !== req.headers.host) throw new HttpError(403, 'Cross-origin requests are not allowed.');
    }

    const { route, params, pathMatched } = router.resolve(req.method, url.pathname);
    if (!route) throw new HttpError(pathMatched ? 405 : 404, pathMatched ? 'Method not allowed.' : 'Not found.');

    const ctx = {
      req, res, url, params, config, db,
      query: Object.fromEntries(url.searchParams),
      ip: clientIp(req, config.trustProxy),
      session: null
    };
    for (const handler of route.handlers) {
      await handler(ctx);
      if (res.writableEnded) return;
    }
    if (!res.writableEnded) throw new Error(`Route ${req.method} ${url.pathname} sent no response`);
  }

  async function handleStatic(req, res, pathname) {
    if (!['GET', 'HEAD'].includes(req.method)) throw new HttpError(405, 'Method not allowed.');
    if (pathname === '/admin') return sendRedirect(res, '/admin/');

    let served;
    if (pathname.startsWith('/uploads/')) {
      served = await serveStatic(req, res, config.uploadsDir, pathname.slice(9), { maxAge: 31536000, immutable: true });
    } else if (pathname.startsWith('/admin/')) {
      served = await serveStatic(req, res, config.adminDir, pathname.slice(7), { maxAge: 300 });
    } else {
      served = await serveStatic(req, res, config.publicDir, pathname.slice(1), { maxAge: 3600 });
    }
    if (served) return;

    res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(req.method === 'HEAD' ? undefined : NOT_FOUND_PAGE);
  }

  function handleError(err, res) {
    if (res.headersSent) return res.destroy();
    if (err instanceof HttpError) {
      const headers = {};
      if (err.status === 413) headers.Connection = 'close';
      if (err.extra.retryAfter) headers['Retry-After'] = String(err.extra.retryAfter);
      return sendJson(res, err.status, { error: err.message, errors: err.extra.errors }, headers);
    }
    log.error('Unhandled error', { message: err.message, stack: err.stack });
    sendJson(res, 500, { error: 'Something went wrong on the server.' });
  }

  return async function handler(req, res) {
    securityHeaders(res, config);
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
      else await handleStatic(req, res, url.pathname);
    } catch (err) {
      handleError(err, res);
    }
  };
}
