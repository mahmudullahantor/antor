import { buildConfig } from './config.js';
import { startServer } from './bootstrap.js';
import { log } from './lib/logger.js';

const config = buildConfig();
const app = await startServer(config);

log.info(`Website running at http://localhost:${app.port}`);
log.info(`Admin panel at   http://localhost:${app.port}/admin/`);

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, async () => {
    await app.close();
    process.exit(0);
  });
}
