import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { loadEnv } from './lib/env.js';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
loadEnv(path.join(ROOT, '.env'));

const flag = (value, fallback) =>
  value === undefined || value === '' ? fallback : ['1', 'true', 'yes', 'on'].includes(String(value).toLowerCase());

/** Builds the runtime configuration. `overrides` is used by the tests. */
export function buildConfig(overrides = {}) {
  const env = process.env;
  const isProd = env.NODE_ENV === 'production';

  let sessionSecret = overrides.sessionSecret || env.SESSION_SECRET || '';
  if (sessionSecret.length < 32 || sessionSecret.startsWith('change-me')) {
    if (isProd) {
      throw new Error('SESSION_SECRET must be a random string of at least 32 characters. See .env.example.');
    }
    sessionSecret = crypto.randomBytes(32).toString('hex'); // development only: logins reset on every restart
  }

  return {
    root: ROOT,
    isProd,
    host: env.HOST || '0.0.0.0',
    port: Number(env.PORT) || 3000,
    sessionSecret,
    sessionHours: Number(env.SESSION_HOURS) || 12,
    cookieSecure: flag(env.COOKIE_SECURE, isProd),
    trustProxy: flag(env.TRUST_PROXY, false),
    adminUser: env.ADMIN_USER || 'admin',
    adminPassword: env.ADMIN_PASSWORD || '',
    maxUploadBytes: (Number(env.MAX_UPLOAD_MB) || 5) * 1024 * 1024,
    // Where the database and uploaded images live. On a host with a persistent disk,
    // point these at the disk, e.g. DATA_DIR=/data and UPLOADS_DIR=/data/uploads.
    dataDir: env.DATA_DIR ? path.resolve(env.DATA_DIR) : path.join(ROOT, 'data'),
    uploadsDir: env.UPLOADS_DIR ? path.resolve(env.UPLOADS_DIR) : path.join(ROOT, 'uploads'),
    publicDir: path.join(ROOT, 'public'),
    adminDir: path.join(ROOT, 'admin'),
    ...overrides
  };
}
