import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { Database } from './lib/db.js';
import { hashPassword } from './lib/security.js';
import { log } from './lib/logger.js';
import { createApp } from './app.js';

async function ensureAdmin(config, db) {
  if (db.get().admin) return;
  const generated = !config.adminPassword;
  const password = config.adminPassword || crypto.randomBytes(9).toString('base64url');
  const passwordHash = await hashPassword(password);
  await db.mutate((data) => {
    data.admin = { username: config.adminUser, passwordHash, sessionsValidAfter: 0 };
  });
  log.info(`Admin account created. Username: ${config.adminUser}`);
  if (generated) {
    console.log(`\n  Your admin password (shown once, change it in Settings): ${password}\n`);
  }
}

/** Prepares folders and data, then starts listening. Returns handles used by index.js and the tests. */
export async function startServer(config) {
  await fs.mkdir(config.dataDir, { recursive: true });
  await fs.mkdir(config.uploadsDir, { recursive: true });

  const seed = JSON.parse(await fs.readFile(path.join(config.root, 'server', 'seed', 'content.json'), 'utf8'));
  const db = await new Database(path.join(config.dataDir, 'db.json')).init({ ...seed, messages: [], admin: null });
  await ensureAdmin(config, db);

  const server = http.createServer(createApp({ config, db }));
  server.requestTimeout = 30_000;
  server.headersTimeout = 15_000;
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(config.port, config.host, resolve);
  });

  return {
    server,
    db,
    port: server.address().port,
    close: () => new Promise((resolve) => {
      server.close(resolve);
      server.closeAllConnections?.();
    })
  };
}
