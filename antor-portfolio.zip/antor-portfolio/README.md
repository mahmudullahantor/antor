# Antor Portfolio

A portfolio website for a graphic designer and photographer, with a built-in **admin panel** and a **contact inbox**.

- **Website:** slider-style pages (Home, Portfolio, Services, About) and a contact form.
- **Admin panel (`/admin/`):** add, edit, hide, reorder and delete projects; edit services, text, links and profile photo; read messages; change password.
- **Backend:** Node.js with **zero dependencies**. No `npm install` is needed.
- **Secure by default:** hashed password (scrypt), signed cookie sessions, CSRF protection, login and contact rate limits, image-type checks, strict security headers.

Requires **Node.js 20 or newer** (https://nodejs.org).

## Quick start

```bash
# 1. Create your settings file
copy .env.example .env        # Windows
cp .env.example .env          # Mac / Linux

# 2. Open .env and set SESSION_SECRET and ADMIN_PASSWORD

# 3. Start
npm start
```

Open http://localhost:3000 for the website and http://localhost:3000/admin/ for the admin panel.

Testing on your own computer over plain `http://`? Add `COOKIE_SECURE=0` to `.env`, otherwise the browser will not keep the admin login cookie.

**Just want to preview the design?** You can double-click `public/index.html`. All pages, the slider, portfolio and services work. The contact form opens your email app and the admin panel is not available, because those need the server (`npm start`).

Useful commands:

| Command | What it does |
|---|---|
| `npm start` | Runs the website |
| `npm run dev` | Runs and restarts on file changes |
| `npm test` | Runs the automated tests |
| `npm run create-admin -- name password` | Resets the admin login (stop the server first) |
| `npm run export-static` | Makes a backend-free copy for GitHub Pages |

## Folder structure

```
antor-portfolio/
├── server/                 Backend (Node.js)
│   ├── index.js            Entry point
│   ├── bootstrap.js        Prepares data folders, creates the admin, starts the server
│   ├── app.js              Request handling: API routes, static files, errors
│   ├── config.js           Reads .env settings
│   ├── constants.js        Categories and limits
│   ├── routes/
│   │   ├── public.js       GET /api/content, POST /api/contact
│   │   ├── auth.js         Login, logout, session, change password
│   │   └── admin.js        Projects, services, settings, messages (login required)
│   ├── lib/                Small reusable modules (router, database, security, uploads...)
│   └── seed/content.json   Starting content used on first run
├── public/                 The website (what visitors see)
│   ├── index.html
│   ├── assets/css/         base, layout, sections, dialogs
│   ├── assets/js/          app, slider, portfolio, services, about, contact, api, dom
│   ├── data/               Static copy of the content (content.js / content.json) used when there is no backend
│   └── images/             Logo, favicon, your photo and demo project images
├── admin/                  The admin panel (HTML, CSS and JS modules)
├── scripts/                create-admin.js, export-static.js
├── test/                   Automated API tests
├── data/                   db.json is created here (your content and messages)
├── uploads/                Images you upload from the admin panel
├── .env.example            Settings template
├── Dockerfile
└── package.json
```

## Portfolio grid ratio

On the Portfolio page, the grid button (next to the category filters) lets visitors choose how the images are shown: **Auto** (every image keeps its own shape, the default), **Random**, or a fixed ratio such as 1:1, 4:3, 3:4, 3:2, 2:3, 4:5, 16:9 and 9:16. The choice is remembered in the visitor's browser. To change the default or add a ratio, edit the `LAYOUTS` list at the top of `public/assets/js/portfolio.js`.

## Using the admin panel

1. Sign in at `/admin/` with `ADMIN_USER` and `ADMIN_PASSWORD` from your `.env`.
   If you left the password empty, a random one is printed in the console the first time you start the server.
2. **Projects:** click *Add project*, upload an image, choose a category. Use *Up/Down* to set the order and untick *Show on the website* to hide a project.
3. **Services:** edit text, the list of items, the button and which project image is shown.
4. **Settings:** headline, About text, skills, email, social links, profile photo and password.
5. **Messages:** messages from the contact form. Click one to read it, then *Reply by email*.

The demo images in `public/images/` (`work-01.jpg` ...) belong to the starting projects. After you upload your own work you can delete the demo projects in the admin panel.

## Hosting

The backend needs a place that runs Node.js. **GitHub Pages cannot run it** (it only hosts static files).

**Option A: Node hosting (full site, admin and contact form)**

Use Render, Railway, Fly.io, a VPS, or any host with Node.js 20+.

- Start command: `npm start`
- Set the environment variables from `.env.example` (`NODE_ENV=production`, `SESSION_SECRET`, `ADMIN_PASSWORD`, `TRUST_PROXY=1`).
- **Important:** your content must be stored on a **persistent disk/volume**. Attach one (for example mounted at `/data`) and set `DATA_DIR=/data` and `UPLOADS_DIR=/data/uploads`. Without a volume, every restart or redeploy erases your projects, uploads and messages.
- A `Dockerfile` is included. Mount one volume at `/data` and set `DATA_DIR=/data` and `UPLOADS_DIR=/data/uploads`.
- Always use HTTPS (hosts like Render and Railway provide it automatically).

**Option B: GitHub Pages (website only)**

```bash
npm run export-static
```

Then publish the `public/` folder on GitHub Pages. The website works from `public/data/content.js`. The contact form opens the visitor's email app instead, and the admin panel is not available. Run `npm run export-static` again whenever you change content.

## Backups

Copy the `data/` and `uploads/` folders (or whatever `DATA_DIR` / `UPLOADS_DIR` point to). That is everything the admin panel creates.

## API (for reference)

Public: `GET /api/health`, `GET /api/content`, `POST /api/contact`
Admin (login + `X-CSRF-Token` header for writes): `/api/admin/session`, `/login`, `/logout`, `/password`, `/projects`, `/services`, `/settings`, `/settings/photo`, `/messages`

## Security notes

- Passwords are stored only as scrypt hashes. Sessions are signed, HttpOnly, SameSite=Strict cookies.
- All admin writes need a CSRF token and a same-origin request.
- Logins are limited to 8 failed tries per 15 minutes per IP; the contact form to 5 messages per hour per IP, plus a hidden honeypot field.
- Uploads are checked by their real file signature (JPG, PNG, WebP, GIF only; SVG is refused) and renamed randomly.
- Keep `.env` private. It is already in `.gitignore`.
